import pygame
import os
import random

pygame.init()
pygame.mixer.init()

#Coustum

WIDTH =900
HEIGHT=900
GREEN=(69,139,0)
FPS=60
Bomberman_SIZE=60
BLOCK_SIZE=WIDTH//Bomberman_SIZE
MOVEMENT=1
time=360
white = (255, 255, 255)
green = (0, 255, 0)
blue = (0, 0, 128)
font_final_game = pygame.font.Font(None,32)
font_score= pygame.font.Font(None,80)
font_pause= pygame.font.Font(None,80)
paused=False
first_iteration=False
end=False
music_off=False

#Window

WIN=pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption("Bomberman")

#blocks
Bomberman_character1=pygame.image.load(
    os.path.join('Assets','character1.png'))
Bomberman_character1=pygame.transform.scale(
    Bomberman_character1,(Bomberman_SIZE,Bomberman_SIZE))

Bomberman_character2=pygame.image.load(
    os.path.join('Assets','character2.png'))
Bomberman_character2=pygame.transform.scale(
    Bomberman_character2,(Bomberman_SIZE,Bomberman_SIZE))

bloc_indestructibil=pygame.image.load(
    os.path.join('Assets','bloc_indestructibil.png'))
bloc_indestructibil=pygame.transform.scale(
    bloc_indestructibil,(Bomberman_SIZE,Bomberman_SIZE))

bloc_destructibil=pygame.image.load(
    os.path.join('Assets','bloc_destructibil.png'))
bloc_destructibil=pygame.transform.scale(
   bloc_destructibil,(Bomberman_SIZE,Bomberman_SIZE))

bomba1=pygame.image.load(
    os.path.join('Assets','bomba1.png'))
bomba1=pygame.transform.scale(
    bomba1,(Bomberman_SIZE,Bomberman_SIZE))

explosion=pygame.image.load(
    os.path.join('Assets','explosion.png'))
explosion=pygame.transform.scale(
    explosion,(Bomberman_SIZE,Bomberman_SIZE))

life=pygame.image.load(
    os.path.join('Assets','life.png'))
life=pygame.transform.scale(
    life,(Bomberman_SIZE,Bomberman_SIZE))

range_bomba=pygame.image.load(
    os.path.join('Assets','range.png'))
range_bomba=pygame.transform.scale(
    range_bomba,(Bomberman_SIZE,Bomberman_SIZE))

contur=pygame.image.load(
    os.path.join('Assets','contur.png'))
contur=pygame.transform.scale(
    contur,(Bomberman_SIZE,Bomberman_SIZE))

#sounds

explosion_sound=pygame.mixer.Sound('Assets/explosion.wav')
explosion_sound.set_volume(0.35)

hit_life=pygame.mixer.Sound('Assets/hit_life.wav')
hit_life.set_volume(0.1)

place_bomb=pygame.mixer.Sound('Assets/place_bomb.wav')

power_up=pygame.mixer.Sound('Assets/power_up.wav')
power_up.set_volume(0.20)

background_sound=pygame.mixer.Sound('Assets/background_sound.mp3')
background_sound.set_volume(0.15)

def draw_window(Character1,Character2):
    WIN.fill(GREEN)
    WIN.blit(Bomberman_character1,(Character1.x,Character1.y))
    WIN.blit(Bomberman_character2,(Character2.x,Character2.y))
    
    pygame.display.update()

class Game:
    
    def __init__(self, player1, player2):
        self.matrix = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                       [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                       [1, 0, 3, 0, 3, 0, 0, 3, 3, 0, 3, 0, 0, 0, 1],
                       [1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1],
                       [1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 3, 0, 2, 0, 1],
                       [1, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1],
                       [1, 0, 0, 3, 0, 0, 0, 0, 0, 3, 0, 0, 2, 0, 1],
                       [1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                       [1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 1],
                       [1, 0, 0, 0, 3, 0, 3, 0, 0, 3, 0, 0, 0, 0, 1],
                       [1, 0, 2, 0, 0, 0, 2, 0, 3, 0, 0, 0, 0, 0, 1],
                       [1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 3, 0, 0, 1],
                       [1, 0, 0, 3, 0, 3, 0, 0, 3, 0, 0, 2, 0, 0, 1],
                       [1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1],
                       [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                       ]
        self.player1=player1
        self.player2=player2
        self.matrix[self.player1.x][self.player1.y] = 7
        self.matrix[self.player2.x][self.player2.y] = 10
        self.timer=0

    def draw(self):    
        global time
        global end
        global music_off
        for i in range(BLOCK_SIZE):
            for j in range(BLOCK_SIZE):
                rect = pygame.Rect(j *Bomberman_SIZE, i * Bomberman_SIZE, Bomberman_SIZE, Bomberman_SIZE)
                floor=pygame.image.load(
                        os.path.join('Assets','sand.jpeg'))
                floor=pygame.transform.scale(
                        floor,(Bomberman_SIZE,Bomberman_SIZE))
                WIN.blit(floor, rect)
                if self.matrix[i][j] == 1:
                    WIN.blit(contur, rect)
                if self.matrix[i][j] == 3:
                    WIN.blit(bloc_indestructibil, rect)
                if self.matrix[i][j] == 2:
                    WIN.blit(bloc_destructibil, rect)

                if self.matrix[i][j] == 5 :
                    WIN.blit(bomba1, rect)
                if self.matrix[i][j] == 7 :
                    WIN.blit(Bomberman_character1, rect)
                if self.matrix[i][j] == 10 :
                    WIN.blit(Bomberman_character2, rect)
                if self.matrix[i][j] == 12:
                    WIN.blit(bomba1, rect)
                    WIN.blit(Bomberman_character1, rect)
                if self.matrix[i][j] ==15:
                    WIN.blit(bomba1, rect)
                    WIN.blit(Bomberman_character2, rect)
                    
                if self.matrix[i][j] == 18:
                    WIN.blit(bomba1, rect)
                    WIN.blit(bomba1, rect)

                if self.matrix[i][j]==50:
                   WIN.blit(life,rect)
                
                if self.matrix[i][j]==100:
                   WIN.blit(range_bomba,rect)

                if self.matrix[i][j]==57 and self.player1.viata<4:
                   self.player1.viata+=1
                   self.player1.score+=25
                   WIN.blit(Bomberman_character1, rect)
                   power_up.play()
                   self.matrix[i][j]=7
                elif self.matrix[i][j]==57 and not self.player1.viata<4:
                    self.matrix[i][j] = 7
                    self.player1.score+=25
                    power_up.play()

                if self.matrix[i][j]==107 and self.player1.bomb_size<BLOCK_SIZE-1:
                   self.player1.bomb_size+=1
                   self.player1.score+=15
                   WIN.blit(Bomberman_character1, rect)
                   power_up.play()
                   self.matrix[i][j]=7  
                
                if self.matrix[i][j]==60 and self.player2.viata<4:
                   self.player2.viata+=1
                   self.player2.score+=25
                   WIN.blit(Bomberman_character2, rect)
                   self.matrix[i][j]=10
                   power_up.play()
                elif self.matrix[i][j]==60 and not self.player2.viata<4:
                    self.matrix[i][j] = 10
                    self.player2.score+=25
                    power_up.play()
                
                if self.matrix[i][j]==110 and self.player2.bomb_size<BLOCK_SIZE-1:
                   self.player2.bomb_size+=1
                   self.player2.score+=15
                   WIN.blit(Bomberman_character2, rect)
                   self.matrix[i][j]=10 
                   power_up.play()  
                

                score_player_1=str(self.player1.score) 
                text=font_score.render(score_player_1, True, green, blue)
                WIN.blit(text,(60,0)) 
                score_player_2=str(self.player2.score) 
                text=font_score.render(score_player_2, True, green, blue)
                WIN.blit(text,(700,0)) 
        self.explode_bomb(self.player1)
        self.explode_bomb(self.player2)
        rect_player1=pygame.Rect(0,0, Bomberman_SIZE, Bomberman_SIZE)
        rect_player2=pygame.Rect(640,0, Bomberman_SIZE, Bomberman_SIZE)
        WIN.blit(Bomberman_character1,rect_player1)
        WIN.blit(Bomberman_character2,rect_player2)
        if self.player1.viata==0 and self.player2.viata==0:
          if self.player1.score>self.player2.score:
            message ='PLAYER1 A CASTIGAT!!!'  
            text=font_pause.render(message, True, green, blue)
            WIN.blit(text,(320,450))
            end=True
            self.handle_events(self.player1,self.player2)
            background_sound.stop()
          else:
                message = 'PLAYER2 A CASTIGAT!!!' 
                text=font_final_game.render(message, True, green, blue)
                WIN.blit(text,(300,450))
                end=True
                self.handle_events(self.player1,self.player2)
                background_sound.stop()
              
        elif self.player1.viata==0:
                message = 'PLAYER2 A CASTIGAT!!!' 
                text=font_final_game.render(message, True, green, blue)
                WIN.blit(text,(300,450))
                end=True
                self.handle_events(self.player1,self.player2)
                background_sound.stop()
        elif self.player2.viata==0:
                message='PLAYER1 A CASTIGAT!!!' 
                text=font_final_game.render(message, True, green, blue)
                WIN.blit(text,(300,450))
                end=True
                self.handle_events(self.player1,self.player2)
                background_sound.stop()
        
        global paused
        if paused and end==False:
            message = 'PAUSE' 
            text=font_pause.render(message, True, green, blue)
            WIN.blit(text,(330,400)) 
            background_sound.stop()
            
            music_off=True
            if(time>0):
                message =str(time) 
                text=font_pause.render(message, True, green, blue)
                WIN.blit(text,(380,0))
        elif paused==False and end==False:
            if(time>0):
                message =str(time) 
                text=font_pause.render(message, True, green, blue)
                WIN.blit(text,(380,0))
                time-=1
                if paused==False and music_off==True:
                    music_off=False
                    background_sound.play()
            if(time==0):
                if self.player1.viata>self.player2.viata:
                    message = 'PLAYER1 A CASTIGAT!!!' 
                    text=font_final_game.render(message, True, green, blue)
                    WIN.blit(text,(300,450))
                    self.timer=1
                    self.handle_events(self.player1,self.player2)
                    background_sound.stop()
                elif self.player1.viata<self.player2.viata:
                    message = 'PLAYER2 A CASTIGAT!!!' 
                    text=font_final_game.render(message, True, green, blue)
                    WIN.blit(text,(300,450))
                    self.timer=1
                    self.handle_events(self.player1,self.player2)
                    background_sound.stop()
                if self.player1.viata==self.player2.viata:
                    if self.player1.score>self.player2.score:
                        message = 'PLAYER1 A CASTIGAT!!!' 
                        text=font_final_game.render(message, True, green, blue)
                        WIN.blit(text,(300,450))
                        self.timer=1
                        self.handle_events(self.player1,self.player2)
                        background_sound.stop()
                    else:
                        message = 'PLAYER2 A CASTIGAT!!!' 
                        text=font_final_game.render(message, True, green, blue)
                        WIN.blit(text,(300,450))
                        self.timer=1
                        self.handle_events(self.player1,self.player2)
                        background_sound.stop()

    
        if self.player1.viata>0:
            for i in range(self.player1.viata):
                rect_lives=pygame.Rect(i*Bomberman_SIZE,j*Bomberman_SIZE,Bomberman_SIZE,Bomberman_SIZE) 
                WIN.blit(life,rect_lives)  
        if self.player2.viata>0:      
            for i in range(self.player2.viata):
                rect_lives=pygame.Rect((3-i)*Bomberman_SIZE+640,j*Bomberman_SIZE,Bomberman_SIZE,Bomberman_SIZE) 
                WIN.blit(life,rect_lives)
        
    def move(self, x, y, player, otherplayer):
        if self.is_valid(player.x + x, player.y + y) and not (player.x+x == otherplayer.x and player.y+y == otherplayer.y):
            self.matrix[player.x][player.y] -= player.val
            player.x += x
            player.y += y
            self.matrix[player.x][player.y] += player.val

    def is_valid(self, x,y):
        if self.matrix[x][y]==3 or self.matrix[x][y]==2 or self.matrix[x][y]==1:
            return False
        else:
            return True
        
    def explode_bomb(self, player):
        if player.bomb_placed and player.bomb_timer <= 0:
            self.matrix[player.bomb_x][player.bomb_y] -= player.bomb_value
            bitMap = [True,True,True,True] # stanga jos dreapta sus
            bitMap[0] = self.process_bomb_direction(player, bitMap[0], 0, 0)
            for i in range(1, player.bomb_size):
                bitMap[0] = self.process_bomb_direction(player, bitMap[0], 0, i)
                bitMap[1] = self.process_bomb_direction(player, bitMap[1],1, i)
                bitMap[2] = self.process_bomb_direction(player, bitMap[2], 2, i)
                bitMap[3] = self.process_bomb_direction(player, bitMap[3], 3, i)
            player.bomb_placed=False
            player.bomb_x = 0
            player.bomb_y = 0
            explosion_sound.play()

    def process_bomb_direction(self, player, shouldProcess, direction, offset):
        if shouldProcess:
            if direction == 0: # stanga
                return self.calculate_position(player.bomb_x - offset, player.bomb_y)
            if direction == 1: # jos
                return self.calculate_position(player.bomb_x, player.bomb_y - offset)
            if direction == 2: # dreapta
                return self.calculate_position(player.bomb_x + offset, player.bomb_y)
            if direction == 3: # sus
                return self.calculate_position(player.bomb_x, player.bomb_y + offset)   
        return shouldProcess
    
    def calculate_position(self, x, y):
        if self.check_boundaries(x, y):
            if self.matrix[x][y] == 2:
                self.matrix[x][y] = 0 # INLOCUIM CU UN BONUS RANDOM
                rand = random.randint(0,4)
                if rand == 0:
                    self.matrix[x][y] =50 
                if rand ==1:
                    self.matrix[x][y]=100
                return False
            if self.matrix[x][y] == 1 or self.matrix[x][y]==3:
                return False
            if x == self.player1.x and y == self.player1.y:
                self.player1.viata -= 1
                self.player2.score+=200
                hit_life.play()
            if x == self.player2.x and y == self.player2.y:
                self.player2.viata -= 1
                self.player1.score+=200
                hit_life.play()
                
            rect = pygame.Rect(y *Bomberman_SIZE, x * Bomberman_SIZE, Bomberman_SIZE, Bomberman_SIZE)
            WIN.blit(explosion, rect)
            return True
        return False
    
    def check_boundaries(self,x,y):
        if x < 0 or x >= BLOCK_SIZE:
            return False
        if y < 0 or y >= BLOCK_SIZE:
            return False
        return True
    
    def place_bomb(self,player):
         if player.bomb_placed == False:
            player.bomb_placed = True
            player.bomb_x = player.x
            player.bomb_y = player.y
            self.matrix[player.x][player.y] = player.val + player.bomb_value
            player.bomb_timer=10
            place_bomb.play()

    def handle_events(self, player1, player2):
        global first_iteration
        global paused
        global end
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()  
            if end==False:
                if paused == False:
                    if player1.viata==0 or player2.viata==0:
                            end=True
                            continue
                    if self.timer==1:
                            end=True
                            continue
                    if event.type ==pygame.KEYDOWN and paused==False:
                        if event.key==pygame.K_SPACE:
                            paused=True
                            first_iteration=True
                    if event.type == pygame.KEYDOWN:
                        handle_keydown_event(event, self, player1, player2)
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE and paused == True and not first_iteration:
                    paused = False
                first_iteration = False
            else:
                if event.type==pygame.KEYDOWN and event.key==pygame.K_ESCAPE:
                    pygame.quit()
                    exit()

def handle_keydown_event(event, game, player1, player2):
    if event.key == pygame.K_LEFT:
        game.move(0, -MOVEMENT, player1,player2)
    if event.key == pygame.K_RIGHT:
        game.move(0, MOVEMENT, player1,player2)     
    if event.key == pygame.K_UP:
        game.move(-MOVEMENT, 0, player1,player2)
    if event.key == pygame.K_DOWN:
        game.move(MOVEMENT, 0, player1,player2)
    if event.key == pygame.K_a:
        game.move(0, -MOVEMENT, player2,player1)
    if event.key == pygame.K_d:
        game.move(0, MOVEMENT, player2,player1)
    if event.key == pygame.K_w:
        game.move(-MOVEMENT, 0, player2,player1)
    if event.key == pygame.K_s:
        game.move(MOVEMENT, 0, player2,player1)
    if event.key == pygame.K_p:
        if not player1.bomb_placed and player1.bomb_timer == 0:
            game.place_bomb(player1)
    if event.key == pygame.K_LSHIFT:
        if not player2.bomb_placed and player2.bomb_timer == 0:
            game.place_bomb(player2)
def draw(game):
    game.draw()
    pygame.display.update()
    
class Player:
    def __init__(self,x,y, val,bVal,bSize):
        self.viata=3
        self.x = x
        self.y = y
        self.val = val
        self.bomb_timer =0
        self.bomb_placed = False
        self.bomb_value = bVal
        self.bomb_x =0
        self.bomb_y =0
        self.bomb_size=bSize
        self.score=0
    def handle_bomb_timer(self):
        if self.bomb_timer>0:
            self.bomb_timer-=1

def main():
    clock=pygame.time.Clock()
    run=True
    global paused
    player1 = Player(1,1,7,5,4)
    player2 = Player(5,5,10,5,4)
    game = Game(player1, player2)
    background_sound.play(-1)
    while run:
        game.handle_events(player1, player2)
        player1.handle_bomb_timer()
        player2.handle_bomb_timer()
        clock.tick(FPS)
        game.draw()
        pygame.display.update()
        
    pygame.quit()

if __name__ =="__main__":
    main()